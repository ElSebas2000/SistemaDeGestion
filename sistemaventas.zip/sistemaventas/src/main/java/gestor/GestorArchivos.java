/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gestor;

import modelo.Producto;
import basedatos.BaseDatosSimulada;
import java.io.*;

public class GestorArchivos {

    public static void guardarProductos(String archivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
            for (Producto p : BaseDatosSimulada.productos.values()) {
                writer.println(p.getId() + "," + p.getNombre() + "," + p.getPrecio() + "," + p.getStock());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void cargarProductos(String archivo) {
        File f = new File(archivo);
        if (!f.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 4) {
                    String id = partes[0];
                    String nombre = partes[1];
                    double precio = Double.parseDouble(partes[2]);
                    int stock = Integer.parseInt(partes[3]);

                    Producto p = new Producto(id, nombre, precio, stock);
                    BaseDatosSimulada.productos.put(id, p);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

