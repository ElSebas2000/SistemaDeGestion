/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo;

import java.util.ArrayList;

public class Venta {
    private String id;
    private ArrayList<ItemVenta> items;

    public Venta(String id) {
        this.id = id;
        this.items = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public ArrayList<ItemVenta> getItems() {
        return items;
    }

    public void agregarItem(ItemVenta item) {
        items.add(item);
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemVenta item : items) {
            total += item.getSubtotal();
        }
        return total;
    }
}
