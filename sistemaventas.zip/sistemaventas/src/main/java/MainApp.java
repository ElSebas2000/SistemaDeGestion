
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

import gestor.GestorArchivos;
import vista.VistaPrincipal;

import javax.swing.*;

public class MainApp {
    public static void main(String[] args) {
        // Cargar productos guardados
        GestorArchivos.cargarProductos("productos.txt");

        SwingUtilities.invokeLater(() -> {
            VistaPrincipal vista = new VistaPrincipal();
            vista.setVisible(true);
        });

        // Guardar productos al cerrar
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            GestorArchivos.guardarProductos("productos.txt");
        }));
    }
}




