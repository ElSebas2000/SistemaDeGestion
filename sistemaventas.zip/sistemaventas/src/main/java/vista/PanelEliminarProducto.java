/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import basedatos.BaseDatosSimulada;
import modelo.Producto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelEliminarProducto extends JPanel {
    private JComboBox<String> comboProductos;
    private JButton btnEliminar;

    public PanelEliminarProducto() {
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Eliminar Producto", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new FlowLayout());
        comboProductos = new JComboBox<>();
        btnEliminar = new JButton("Eliminar");

        centro.add(new JLabel("Seleccionar producto:"));
        centro.add(comboProductos);
        centro.add(btnEliminar);
        add(centro, BorderLayout.CENTER);

        // Cargar productos
        cargarProductos();

        // Acción eliminar
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String seleccionado = (String) comboProductos.getSelectedItem();
                if (seleccionado == null || seleccionado.isEmpty()) {
                    JOptionPane.showMessageDialog(PanelEliminarProducto.this, "No hay producto seleccionado.");
                    return;
                }

                String idProducto = seleccionado.split(" - ")[0];
                int confirm = JOptionPane.showConfirmDialog(PanelEliminarProducto.this,
                        "¿Estás seguro de eliminar el producto " + seleccionado + "?", "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    BaseDatosSimulada.productos.remove(idProducto);
                    JOptionPane.showMessageDialog(PanelEliminarProducto.this, "Producto eliminado.");
                    cargarProductos(); // actualizar lista
                }
            }
        });
    }

    private void cargarProductos() {
        comboProductos.removeAllItems();
        for (Producto p : BaseDatosSimulada.productos.values()) {
            comboProductos.addItem(p.getId() + " - " + p.getNombre());
        }
    }

    @Override
    public void setVisible(boolean aFlag) {
        super.setVisible(aFlag);
        if (aFlag) cargarProductos();
    }
}
