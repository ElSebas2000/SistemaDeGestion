/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package vista;

import basedatos.BaseDatosSimulada;
import modelo.ItemVenta;
import modelo.Producto;
import modelo.Venta;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelRegistrarVenta extends JPanel {
    private JComboBox<String> comboProductos;
    private JTextField txtCantidad;
    private JTextArea txtResumen;
    private JButton btnAgregar, btnFinalizar;
    private Venta ventaActual;

    public PanelRegistrarVenta() {
        setLayout(new BorderLayout());

        // Panel Superior
        JPanel panelSuperior = new JPanel(new GridLayout(3, 2));
        panelSuperior.add(new JLabel("Producto:"));
        comboProductos = new JComboBox<>();
        panelSuperior.add(comboProductos);

        panelSuperior.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelSuperior.add(txtCantidad);

        btnAgregar = new JButton("Agregar Item");
        panelSuperior.add(btnAgregar);

        btnFinalizar = new JButton("Finalizar Venta");
        panelSuperior.add(btnFinalizar);

        add(panelSuperior, BorderLayout.NORTH);

        // Área de Resumen
        txtResumen = new JTextArea();
        txtResumen.setEditable(false);
        JScrollPane scroll = new JScrollPane(txtResumen);
        add(scroll, BorderLayout.CENTER);

        // Inicializar venta
        ventaActual = new Venta("V" + (BaseDatosSimulada.ventas.size() + 1));

        // Cargar productos en el combo
        cargarProductosEnCombo();

        // Acción del botón "Agregar Item"
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idProducto = (String) comboProductos.getSelectedItem();
                if (idProducto == null || idProducto.isEmpty()) {
                    JOptionPane.showMessageDialog(PanelRegistrarVenta.this, "Debe seleccionar un producto.");
                    return;
                }

                Producto productoSeleccionado = BaseDatosSimulada.productos.get(idProducto.split(" - ")[0]);

                int cantidad;
                try {
                    cantidad = Integer.parseInt(txtCantidad.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(PanelRegistrarVenta.this, "Cantidad no válida.");
                    return;
                }

                if (productoSeleccionado != null && productoSeleccionado.disminuirStock(cantidad)) {
                    ItemVenta item = new ItemVenta(productoSeleccionado, cantidad);
                    ventaActual.agregarItem(item);

                    // Mostrar resumen
                    txtResumen.append("Producto: " + productoSeleccionado.getNombre() + " | Cantidad: " + cantidad + " | Subtotal: $" + item.getSubtotal() + "\n");

                    // Limpiar cantidad
                    txtCantidad.setText("");
                } else {
                    JOptionPane.showMessageDialog(PanelRegistrarVenta.this, "No hay suficiente stock.");
                }
            }
        });

        // Acción del botón "Finalizar Venta"
        btnFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ventaActual.getItems().isEmpty()) {
                    JOptionPane.showMessageDialog(PanelRegistrarVenta.this, "Debe agregar al menos un producto.");
                    return;
                }

                // Guardar venta en la base de datos
                BaseDatosSimulada.ventas.add(ventaActual);
                JOptionPane.showMessageDialog(PanelRegistrarVenta.this, "Venta finalizada exitosamente. Total: $" + ventaActual.calcularTotal());

                // Limpiar pantalla
                ventaActual = new Venta("V" + (BaseDatosSimulada.ventas.size() + 1));
                txtResumen.setText("");
                txtCantidad.setText("");
                cargarProductosEnCombo(); // Recargar productos
            }
        });
    }

    private void cargarProductosEnCombo() {
        comboProductos.removeAllItems();

        if (BaseDatosSimulada.productos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay productos registrados.");
            return;
        }

        for (Producto p : BaseDatosSimulada.productos.values()) {
            comboProductos.addItem(p.getId() + " - " + p.getNombre());
        }
    }

    @Override
    public void setVisible(boolean aFlag) {
        super.setVisible(aFlag);
        if (aFlag) {
            cargarProductosEnCombo(); // Actualizar productos al mostrar el panel
        }
    }
}

 

