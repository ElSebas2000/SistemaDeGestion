package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VistaPrincipal extends JFrame {
    private CardLayout layout;
    private JPanel panelContenido;

    public VistaPrincipal() {
        setTitle("Sistema de Ventas");
        setSize(1000, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 🟦 Menú lateral estilizado
        JPanel panelMenu = new JPanel();
        panelMenu.setLayout(new GridLayout(3, 1, 20, 20));
        panelMenu.setBackground(new Color(33, 150, 243));
        panelMenu.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20)); // espacio interno

        // Botones estilizados
        JButton btnProductos = crearBotonMenu("📦 Registrar Producto");
        JButton btnVentas = crearBotonMenu("💵 Registrar Venta");
        JButton btnReportes = crearBotonMenu("📊 Ver Reportes");

        panelMenu.add(btnProductos);
        panelMenu.add(btnVentas);
        panelMenu.add(btnReportes);

        // Panel central con CardLayout
        layout = new CardLayout();
        panelContenido = new JPanel(layout);
        panelContenido.setBackground(new Color(245, 245, 245)); // fondo gris claro

        panelContenido.add(new PanelRegistrarProducto(), "productos");
        panelContenido.add(new PanelRegistrarVenta(), "ventas");
        panelContenido.add(new PanelReportes(), "reportes");

        // Listeners
        btnProductos.addActionListener(e -> layout.show(panelContenido, "productos"));
        btnVentas.addActionListener(e -> layout.show(panelContenido, "ventas"));
        btnReportes.addActionListener(e -> layout.show(panelContenido, "reportes"));

        // Layout principal
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelMenu, BorderLayout.WEST);
        getContentPane().add(panelContenido, BorderLayout.CENTER);
    }

    private JButton crearBotonMenu(String texto) {
        JButton boton = new JButton(texto);
        boton.setFocusPainted(false);
        boton.setBackground(new Color(25, 118, 210));
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(21, 101, 192), 2),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover efecto
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                boton.setBackground(new Color(21, 101, 192));
            }

            public void mouseExited(MouseEvent evt) {
                boton.setBackground(new Color(25, 118, 210));
            }
        });
        return boton;
    }
}

