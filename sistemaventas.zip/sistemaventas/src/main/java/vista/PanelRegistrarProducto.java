package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import modelo.Producto;
import basedatos.BaseDatosSimulada;

public class PanelRegistrarProducto extends JPanel {
    private JTextField txtId, txtNombre, txtPrecio, txtStock;
    private JButton btnRegistrar;

    public PanelRegistrarProducto() {
        setBackground(new Color(33, 33, 33)); // Fondo general oscuro
        setLayout(new GridBagLayout()); // Centrado

        // Panel blanco al centro
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);
        panelFormulario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 100), 1),
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        Font fontLabel = new Font("Segoe UI", Font.PLAIN, 16);
        Font fontField = new Font("Segoe UI", Font.PLAIN, 16);

        // Fila 1 - ID
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        txtId = new JTextField(15); txtId.setFont(fontField);
        panelFormulario.add(txtId, gbc);

        // Fila 2 - Nombre
        gbc.gridx = 0; gbc.gridy++;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombre = new JTextField(15); txtNombre.setFont(fontField);
        panelFormulario.add(txtNombre, gbc);

        // Fila 3 - Precio
        gbc.gridx = 0; gbc.gridy++;
        panelFormulario.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1;
        txtPrecio = new JTextField(15); txtPrecio.setFont(fontField);
        panelFormulario.add(txtPrecio, gbc);

        // Fila 4 - Stock
        gbc.gridx = 0; gbc.gridy++;
        panelFormulario.add(new JLabel("Stock:"), gbc);
        gbc.gridx = 1;
        txtStock = new JTextField(15); txtStock.setFont(fontField);
        panelFormulario.add(txtStock, gbc);

        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        btnRegistrar = new JButton("Registrar Producto");
        btnRegistrar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnRegistrar.setBackground(new Color(33, 150, 243));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegistrar.setPreferredSize(new Dimension(200, 40));
        panelFormulario.add(btnRegistrar, gbc);

        // Validación y acción
        btnRegistrar.addActionListener(e -> {
            String id = txtId.getText().trim();
            String nombre = txtNombre.getText().trim();
            String precio = txtPrecio.getText().trim();
            String stock = txtStock.getText().trim();

            if (!id.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "El ID debe contener solo números.");
                return;
            }
            if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
                JOptionPane.showMessageDialog(this, "El nombre debe contener solo letras.");
                return;
            }

            try {
                double p = Double.parseDouble(precio);
                int s = Integer.parseInt(stock);
                BaseDatosSimulada.productos.put(id, new Producto(id, nombre, p, s));
                JOptionPane.showMessageDialog(this, "Producto registrado correctamente.");
                txtId.setText(""); txtNombre.setText(""); txtPrecio.setText(""); txtStock.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        add(panelFormulario); // Añadir panel al centro
    }
}

