package vista;

import javax.swing.*;
import java.awt.*;
import basedatos.BaseDatosSimulada;
import modelo.Producto;
import modelo.Venta;

public class PanelReportes extends JPanel {
    private JTextArea areaReportes;

    public PanelReportes() {
        setBackground(new Color(33, 33, 33));
        setLayout(new GridBagLayout());

        // Panel de contenido con BorderLayout
        JPanel panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBackground(Color.WHITE);
        panelContenido.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 100), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        panelContenido.setPreferredSize(new Dimension(600, 400));

        // Área de texto para mostrar los reportes
        areaReportes = new JTextArea();
        areaReportes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        areaReportes.setEditable(false);
        areaReportes.setLineWrap(true);  // Asegura que el texto no se salga del área
        areaReportes.setWrapStyleWord(true); // Ajusta la línea para que no corte palabras

        // Utilizamos JScrollPane para permitir desplazamiento
        JScrollPane scroll = new JScrollPane(areaReportes);
        scroll.setPreferredSize(new Dimension(550, 300));

        // Botón para cargar los reportes
        JButton btnCargar = new JButton("Cargar Reportes");
        btnCargar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnCargar.setBackground(new Color(33, 150, 243));
        btnCargar.setForeground(Color.WHITE);
        btnCargar.setFocusPainted(false);
        btnCargar.setPreferredSize(new Dimension(200, 40));

        // Acción para cargar los reportes cuando se presiona el botón
        btnCargar.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("=== Productos ===\n");
            for (Producto p : BaseDatosSimulada.productos.values()) {
                sb.append(p.toString()).append("\n");  // Añadimos la representación en cadena del producto
            }
            sb.append("\n=== Ventas ===\n");
            for (Venta v : BaseDatosSimulada.ventas) {
                sb.append(v.toString()).append("\n");  // Añadimos la representación en cadena de la venta
            }
            // Establecemos el texto del área de reportes
            areaReportes.setText(sb.toString());
        });

        // Añadimos el botón y el scroll al panel de contenido
        panelContenido.add(scroll, BorderLayout.CENTER);
        panelContenido.add(btnCargar, BorderLayout.SOUTH);

        // Añadimos el panel de contenido al panel principal
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);  // Añadimos un poco de espacio
        add(panelContenido, gbc);
    }
}
