

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package servicio;

import basedatos.BaseDatosSimulada;
import modelo.ItemVenta;
import modelo.Producto;
import modelo.Venta;

import java.util.List;

public class VentaService {

    public Venta crearVenta() {
        String idVenta = "V" + (BaseDatosSimulada.ventas.size() + 1);
        return new Venta(idVenta);
    }

    public boolean agregarItemAVenta(Venta venta, Producto producto, int cantidad) {
        if (producto.disminuirStock(cantidad)) {
            ItemVenta item = new ItemVenta(producto, cantidad);
            venta.agregarItem(item);
            return true;
        }
        return false;
    }

    public void finalizarVenta(Venta venta) {
        BaseDatosSimulada.ventas.add(venta);
    }

    public List<Venta> obtenerVentas() {
        return BaseDatosSimulada.ventas;
    }
}
