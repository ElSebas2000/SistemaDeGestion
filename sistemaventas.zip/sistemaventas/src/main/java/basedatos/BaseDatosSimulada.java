
package basedatos;

import modelo.Producto;
import modelo.Venta;
import java.util.HashMap;
import java.util.ArrayList;

public class BaseDatosSimulada {
    public static HashMap<String, Producto> productos = new HashMap<>();
    public static ArrayList<Venta> ventas = new ArrayList<>();
    
    public static void agregarProducto(Producto producto) {
    productos.put(producto.getId(), producto);
    
    }
}


